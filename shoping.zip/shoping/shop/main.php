<!DOCTYPE html>
<html>
<head>
	<title>Animated Login Form</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
.shop{
  display: flex;
  flex-wrap: wrap;
 
}
.items{
 padding: 10px;
 background-color: #47c9af;
 border-radius: 3px;
 border-color: navajowhite;
 margin: 10px;
 color: #ffffff;
}
#right{
    text-align: right;
    padding-left: 20px;
}

    </style>
</head>
<body>
	
<div id='cssmenu'>
	<ul>
	   <li id="left" class='active'><a href='#'>Home</a></li>
	   <li id="left"><a href='#'>cart</a></li>
	   <li id="left"><a href='#'>coupan</a></li>
	   <li class="right"><a  href='#'>login</a></li>
	</ul>
    </div>
    

<div class="shop">
<?php require_once("../shop/items.php"); ?>
</div>


</body>
</html>