<?php
session_start();
    $con =mysqli_connect('127.0.0.1','root','','shopping');
    if(!$con){
       echo 'database not connected';
    }
    $User = $_POST['user'];
    $Pass = $_POST['pass'];
    $_SESSION['name']= $User;

    $query = mysqli_query($con, "SELECT * FROM buyer WHERE user='$User' AND pass='$Pass'");
    $rows = mysqli_num_rows($query);

    if($rows == 1){
        header("Location: ../shop/main.php");
    }
    else
    {
    echo "Username of Password is Invalid";
    }
?>