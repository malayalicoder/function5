<?php
session_start();
    $con =mysqli_connect('127.0.0.1','root','','shopping');
    if(!$con){
       echo 'database not connected';
    }
    $User = $_POST['us'];
    $Pass = $_POST['pa'];
    $_SESSION['name']= $User;

    $query = mysqli_query($con, "SELECT * FROM seller WHERE user='$User' AND pass='$Pass'");
    $rows = mysqli_num_rows($query);

    if($rows == 1){
        header("Location: ../sellerpage/sellerpage.php");
    }
    else
    {
    echo "Username of Password is Invalid";
    }
?>