<?php     
$con =mysqli_connect('127.0.0.1','root','','shopping');
   
     $query = mysqli_query($con, "SELECT item,pri,ds,img1,img2,img3 FROM sellitem");
     $rows = mysqli_num_rows($query);
     if ($query->num_rows > 0) {
      while($row = $query->fetch_assoc()) {
          $item=$row['item'];
          $prc=$row['pri'];
          $abt=$row['ds'];
          $img1=$row['img1'];
          $img2=$row['img2'];
          $img3=$row['img3'];
         
             
             
            ?>
      
      <div class="items">
                        
                        <p class="w3-center"><img src="<?php echo $img1 ; ?>"  style="height:106px;width:106px" alt="Avatar"></p>
                        <p class="other"><?php echo $item ; ?><label id="right"> <?php echo "₹".$prc ; ?></label> </p>
                        <p class="other"> <?php echo $abt ; ?></p>
                       
      </div>             
              
                

                <?php
              
        }
    }

   