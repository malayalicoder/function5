<?php
session_start();
$User=$_SESSION['name'];
$target_dir = "../sellerpage/uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$target_file1 = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$target_file2 = $target_dir . basename($_FILES["fileToUpload2"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));

move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)&&move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file1)&&move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], $target_file2);
      
$con=mysqli_connect('127.0.0.1','root','','shopping');
  
  $Name= $_POST['name'];
  $price= $_POST['job'];
  $about= $_POST['plc'];
  $sql="INSERT INTO sellitem (item, pri, ds, img1, img2, img3, user) VALUES ('$Name','$price','$about','$target_file','$target_file1','$target_file2', '$User')";
  if (!mysqli_query($con,$sql)) {
      echo "note avilable";
  }
  else 
  {
    header("refresh:0; url=../sellerpage/sellerpage.php");
  }
 

?>