<html>
<head>
	<title>Animated Login Form</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .itemadd{
            align-content: center;
    background-color: aqua;
    width: max-content;
    height: max-content;
    border-radius: 5px;
    font-family: cursive;
    text-align: left;
    padding: 10px 40px 25px;
    margin: 50px auto;
}
.input{
    background-color: bisque;
    margin-top: 10px;
} 

.btn{
    text-align: center;
}
.shop{
  display: flex;
  flex-wrap: wrap;
}
.items{
 padding: 10px;
 background-color: #47c9af;
 border-radius: 3px;
 border-color: navajowhite;
 margin: 10px;
 color: #ffffff;
}
#right{
    text-align: right;
    padding-left: 20px;
}
.re{
    display: none;
}
    </style>
</head>

<body>
<?php
session_start();
$_SESSION['name'];
?>


<div id='cssmenu'>
	<ul>
        <li id="left"><a>ADD ITEM</a></li>
        <li id="left"></li>
        <li id="left"></li>
	   <li class="right"><h2><?php echo $_SESSION['name'];?></h2></li>
	</ul>
	</div>
    
    
    <div align="center" class="itemadd">
    <form  action="sell.php" method="post" enctype="multipart/form-data">
            
            <label > ITEM NAME:<input class="input" type="text" name="name" required></label><br>

            <label >PRICE:<input class="input" type="number" name="job" required><br></label> 

            <label >ABOUT: <input class="input" type="text" name="plc" required><br></label>
  
            <label >1 IMAGE:<input class="input" type="file" name="fileToUpload" id="fileToUpload" ><br></label>
        
            <label > 2 IMAGE:<input class="input" type="file" name="fileToUpload1" id="fileToUpload1" ><br></label>
       
            <label > 3 IMAGE:<input class="input" type="file" name="fileToUpload2" id="fileToUpload1" ><br></label>
       

        <input class="btn" type="submit" value="SELL ITEM" name="submit">
    </form>

    </div>
<div class="shop">
<?php require_once("../sellerpage/add.php"); ?>
</div>


<body>
</html>