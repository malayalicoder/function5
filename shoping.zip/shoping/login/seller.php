<!DOCTYPE html>
<html>
<head>
	<title>Animated Login Form</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

	<img class="wave" src="img/wave.png">
	
<div id='cssmenu'>
	<ul>
	   <li id="left" class='active'><a href='#'>Home</a></li>
	   <li id="left"><a href='#'>cart</a></li>
	   <li id="left"><a href='#'>coupan</a></li>
	   <li class="right"><a  href='#'>login</a></li>
	</ul>
	</div>
	<div class="container">
		<div class="img">
			<img src="img/bg.svg">
		</div>
		<div class="login-content">
			<form action="logsel.php" method="post">
				<img src="img/avatar.svg">
				<h2 class="title">seller</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Username</h5>
           		   		<input type="text" name="us" class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Password</h5>
           		    	<input type="password" name="pa" class="input">
            	   </div>
				</div>
				<a class="account" href="../register/register.php">create a account</a>
            	<a href="../login/login.php">login as buyer</a>
            	<input type="submit" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
