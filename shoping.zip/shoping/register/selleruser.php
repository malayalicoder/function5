<?php

    $con =mysqli_connect('127.0.0.1','root','','shopping');
    if(!$con){
        echo 'database not connected';
    }

    $User = $_POST['usernames'];
    $Pass = $_POST['passwords'];

    $sql = "INSERT INTO seller (user,pass) VALUE ('$User','$Pass')";

    
    $query = mysqli_query($con, "SELECT * FROM seller WHERE user='$User'");
    $rows = mysqli_num_rows($query);
 
    if($rows == 1){
    echo "already exit";
    header("refresh:5; url=../login/seller.php");
    }else{

        if (!mysqli_query($con,$sql)) {
            echo "note avilable";
        }
      else 
        {
            header("Location: ../login/seller.php");
        }
    }


?>