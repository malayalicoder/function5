<?php

    $con =mysqli_connect('127.0.0.1','root','','shopping');
    if(!$con){
        echo 'database not connected';
    }

    $User = $_POST['username'];
    $Pass = $_POST['password'];

    $sql = "INSERT INTO buyer (user,pass) VALUE ('$User','$Pass')";

    $query = mysqli_query($con, "SELECT * FROM buyer WHERE user='$User'");
    $rows = mysqli_num_rows($query);
 
    if($rows == 1){
    echo "already exit";
    header("refresh:5; url=../login/login.php");
    }else{

        if (!mysqli_query($con,$sql)) {
            echo "note avilable";
        }
      else 
        {
            header("Location: ../login/login.php"); 
        }
    }


    

?>